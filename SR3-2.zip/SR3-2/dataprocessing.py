import numpy as np
import torch
from torch.utils.data import Dataset
import torchvision.transforms as transforms
import torch.nn.functional as F

import xarray as xr
import torch
from torch.utils.data import Dataset
import torch.nn.functional as F
import torchvision.transforms as transforms

class SRDataset(Dataset):
    def __init__(self, hr_data, hr_sz=256, lr_sz=64, _transforms=None):
        super().__init__()
        
        self.hr_data = hr_data
        
        if _transforms:
            self.transforms = _transforms
        else:
            self.transforms = transforms.Compose([
                transforms.Lambda(lambda x: (x - np.min(x)) / (np.max(x) - np.min(x))),
                transforms.Lambda(lambda x: torch.tensor(x, dtype=torch.float32)),
                transforms.Lambda(lambda x: x.unsqueeze(0)),
                transforms.Normalize((0.5, ), (0.5,))
            ])
        
        self.hr_sz = hr_sz
        self.lr_sz = lr_sz


    def __len__(self):
        
        return self.hr_data.shape[0]
    

    def __getitem__(self, index):
        data = self.hr_data[index]
        # Normalization
        data = self.transforms(data) # Size of data is (1, 256, 256)
        
        # F requires input size to be (N, C, H, W)
        lr_data = F.interpolate(data.unsqueeze(0), size=(self.lr_sz, self.lr_sz), mode='bicubic')
        lr_data = F.interpolate(lr_data, size=(self.hr_sz, self.hr_sz), mode='bicubic').squeeze(0)

        hr_data = data.squeeze(0)
        
        return lr_data, hr_data.unsqueeze(0)