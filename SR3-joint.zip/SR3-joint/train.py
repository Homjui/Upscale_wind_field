import xarray as xr
import os
from time import time

# import class and functions from other files
from modules import *
from dataprocessing import *
from earlystop import *

import torch
from torch.utils.data import Dataset, DataLoader, ConcatDataset
import torch.nn as nn
import torch.nn.functional as F

def train_ddpm(wind_ds=None, time_steps=1000, epochs=20, batch_size=8, device="cuda", 
               checkpoint_path="checkpoint_path", patience=5): 
    
    ddpm1 = DiffusionModel1(time_steps=time_steps)
    ddpm2 = DiffusionModel2(time_steps=time_steps)

    opt = torch.optim.Adam(
        list(ddpm1.model.parameters()) + list(ddpm2.model.parameters()),
        lr=1e-4
    )

    criterion = nn.MSELoss(reduction="mean")
    early_stopper = EarlyStopper(patience=patience)

    # load checkpoint
    start_epoch = load_checkpoint(ddpm1.model, ddpm2.model, opt, checkpoint_path)

    ddpm1.model.to(device)
    ddpm2.model.to(device)

    # prepare datasets
    datasets = []
    tite_number = wind_ds.shape[0]
    
    for i in range(tite_number):
        sub_wind_ds = wind_ds.sel(tile=i)
        datasets.append(SRDataset(hr_data=sub_wind_ds.values, hr_sz=256, mr_sz = 64, lr_sz=16))
        if i % 10 == 0:
            print(f"Finished preparing dataset {i}", flush=True)

    combined_dataset = ConcatDataset(datasets)
    training_ds = DataLoader(combined_dataset, batch_size=batch_size, shuffle=True, drop_last=True, num_workers=2)
    
    print(f"---------------------------------", flush=True)
    print(f"Finished preparing all datasets", flush=True)

    # start from checkpoint epoch
    for ep in range(start_epoch, epochs): 
        ddpm1.model.train()
        ddpm2.model.train()
        
        print(f"---------------------------------", flush=True)
        print(f"Epoch {ep}:", flush=True)

        losses = []
        stime = time()

        for i, (x, y, z) in enumerate(training_ds):
            bs = z.shape[0]
            x, y, z = x.to(device), y.to(device), z.to(device)

            ts1 = torch.randint(low=1, high=ddpm1.time_steps, size=(bs,))
            gamma1 = ddpm1.alpha_hats[ts1].to(device)
            ts1 = ts1.to(device)

            ts2 = torch.randint(low=1, high=ddpm2.time_steps, size=(bs,))
            gamma2 = ddpm2.alpha_hats[ts2].to(device)
            ts2 = ts2.to(device)

            # Stage 1: 16x16 → 64x64
            x1_noisy, noise1 = ddpm1.add_noise(y, ts1)
            x1_input = torch.cat([x, x1_noisy], dim=1) # both are (bs, 1, 64, 64)
            
            # Predict noise
            pred_noise1 = ddpm1.model(x1_input, gamma1)
            loss1 = criterion(noise1, pred_noise1)

            x1_denoised = ddpm1.denoise(x1_noisy, pred_noise1, ts1)

            # Stage 2: 64x64 → 256x256
            x2_in = F.interpolate(x1_denoised, size=(256, 256), mode="bicubic")

            x2_noisy, noise2 = ddpm2.add_noise(z, ts2)
            x2_input = torch.cat([x2_in, x2_noisy], dim=1) # both are (bs, 1, 256, 256)
            
            # Predict noise
            pred_noise2 = ddpm2.model(x2_input, gamma2)
            loss2 = criterion(noise2, pred_noise2)

            loss = 0.8 * loss1 + 0.2 * loss2

            opt.zero_grad()
            loss.backward()
            opt.step()

            losses.append(loss.item())

            if i % 1000 == 0:
                print(f"Loss: {loss.item():.6f}; step {i}; epoch {ep}", flush=True)

        avg_loss = sum(losses) / len(losses)
        ftime = time()
        print(f"Epoch trained in {ftime - stime:.2f}s; Avg loss => {avg_loss:.6f}", flush=True)

        torch.save({
            "epoch": ep,
            "ddpm1": ddpm1.model.state_dict(),
            "ddpm2": ddpm2.model.state_dict(),
            "optimizer": opt.state_dict()
        }, f"save_path/sr_joint_{ep}.pt")

        save_checkpoint(ep, ddpm1.model, ddpm2.model, opt, checkpoint_path)

        if early_stopper.should_stop(avg_loss):
            print(f"Early stopping triggered at epoch {ep}", flush=True)
            break



def save_checkpoint(epoch, model1, model2, optimizer, checkpoint_path=None):
    checkpoint = {
        "epoch": epoch,
        "model1_state_dict": model1.state_dict(),
        "model2_state_dict": model2.state_dict(),
        "optimizer_state_dict": optimizer.state_dict()
    }
    torch.save(checkpoint, checkpoint_path)
    print(f"Checkpoint saved at epoch {epoch}", flush=True)


def load_checkpoint(model1, model2, optimizer, checkpoint_path=None):
    if checkpoint_path is not None and os.path.exists(checkpoint_path):
        checkpoint = torch.load(checkpoint_path)
        model1.load_state_dict(checkpoint["model1_state_dict"])
        model2.load_state_dict(checkpoint["model2_state_dict"])
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        print(f"Checkpoint loaded. Resuming from epoch {checkpoint['epoch'] + 1}", flush=True)
        return checkpoint["epoch"] + 1
    return 0


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    path = "data_path"
    ds = xr.open_zarr(path)
    
    train_ddpm(
        wind_ds=ds["wind_speed"],
        time_steps=1000,
        epochs=50,
        batch_size=8,
        device=device,
        checkpoint_path="checkpoint_path",
        patience=5
    )