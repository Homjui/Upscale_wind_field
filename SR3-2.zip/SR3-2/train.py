import xarray as xr
import os
from time import time

# import class and functions from other files
from modules import *
from dataprocessing import *
from earlystop import *

import torch
from torch.utils.data import Dataset, DataLoader, ConcatDataset
import torch.nn as nn
import torch.nn.functional as F

def train_ddpm(wind_ds=None, time_steps=1000, epochs=20, batch_size=8, device="cuda", 
               image_dims=(1, 256, 256), low_res_dims=(1, 64, 64), 
               checkpoint_path="checkpoint_here", patience=5): 
    
    ddpm = DiffusionModel(time_steps=time_steps)
    opt = torch.optim.Adam(ddpm.model.parameters(), lr=1e-3)
    criterion = nn.MSELoss(reduction="mean")
    early_stopper = EarlyStopper(patience=patience)

    # load checkpoint
    start_epoch = load_checkpoint(ddpm.model, opt, checkpoint_path)

    ddpm.model.to(device)

    # prepare datasets
    datasets = []
    tite_number = wind_ds.shape[0]
    
    for i in range(tite_number):
        sub_wind_ds = wind_ds.sel(tile=i)
        datasets.append(SRDataset(hr_data=sub_wind_ds.values, hr_sz=256, lr_sz=64))
        if i % 10 == 0:
            print(f"Finished preparing dataset {i}", flush=True)
        
        break

    combined_dataset = ConcatDataset(datasets)
    training_ds = DataLoader(combined_dataset, batch_size=batch_size, shuffle=True, drop_last=True, num_workers=2)
    
    print(f"---------------------------------", flush=True)
    print(f"Finished preparing all datasets", flush=True)

    # start from checkpoint epoch
    for ep in range(start_epoch, epochs): 
        ddpm.model.train()
        print(f"---------------------------------", flush=True)
        print(f"Epoch {ep}:")
        losses = []
        stime = time()
        
        for i, (x, y) in enumerate(training_ds):
            bs = y.shape[0]
            x, y = x.to(device), y.to(device)

            ts = torch.randint(low=1, high=ddpm.time_steps, size=(bs,))
            gamma = ddpm.alpha_hats[ts].to(device)
            print(f"gamma shape: {gamma.shape}")
            ts = ts.to(device=device)
            print(f"ts shape: {ts.shape}")

            y, target_noise = ddpm.add_noise(y, ts)
            print(f"y shape: {y.shape}")
            print(f"target_noise shape: {target_noise.shape}")

            y = torch.cat([x, y], dim=1)
            print(f"y shape after cat: {y.shape}")
            
            predicted_noise = ddpm.model(y, gamma)
            print(f"predicted_noise shape: {predicted_noise.shape}")
            loss = criterion(target_noise, predicted_noise)
            
            opt.zero_grad()
            loss.backward()
            opt.step()
            
            losses.append(loss.item())

            if i % 1000 == 0:
                print(f"Loss: {loss.item()}; step {i}; epoch {ep}", flush=True)

        avg_loss = sum(losses) / len(losses)
        ftime = time()
        print(f"Epoch trained in {ftime - stime}s; Avg loss => {avg_loss}", flush=True)

        torch.save(ddpm.state_dict(), f"output_path/sr_{ep}.pt")
        print(flush=True)

        # save checkpoint
        save_checkpoint(ep, ddpm.model, opt, checkpoint_path)

        # early stopping
        if early_stopper.should_stop(avg_loss):
            print(f"Early stopping triggered at epoch {ep}", flush=True)
            break


def save_checkpoint(epoch, model, optimizer, checkpoint_path = None):

    checkpoint = {
        "epoch": epoch,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict()
    }
    torch.save(checkpoint, checkpoint_path)
    print(f"Checkpoint saved at epoch {epoch}", flush=True)


def load_checkpoint(model, optimizer, checkpoint_path = None):
    
    if os.path.exists(checkpoint_path):
        checkpoint = torch.load(checkpoint_path)
        model.load_state_dict(checkpoint["model_state_dict"])
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        print(f"Checkpoint loaded. Resuming from epoch {checkpoint['epoch']+1}", flush=True)
        return checkpoint["epoch"] + 1 
    return 0


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    path = "data_path"
    ds = xr.open_zarr(path)
    train_ddpm(wind_ds=ds["wind_speed"], time_steps=1000, epochs=50, batch_size=8, device=device, 
               checkpoint_path="checkpoint_path", patience=5)
