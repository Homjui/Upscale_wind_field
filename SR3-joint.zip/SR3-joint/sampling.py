from dataprocessing import *
from modules import DiffusionModel1, DiffusionModel2

from time import time
import torch
from torch.utils.data import Dataset, DataLoader, ConcatDataset

def sample(ddpm1, ddpm2, wind_ds = None, device = "cuda", batch_size = 16):
    # Load the trained model
    ddpm1.model.to(device)
    ddpm2.model.to(device)
    ddpm1.model.eval()
    ddpm2.model.eval()

    datasets = []
    tite_number = wind_ds.shape[0]

    for i in range(tite_number):
        sub_wind_ds = wind_ds.sel(tile=i) # sub_wind_ds: (24, 256, 256)

        datasets.append(SRDataset(hr_data=sub_wind_ds.values, hr_sz=256, lr_sz=64))
        if i % 10 == 0:
            print(f"Finished preparing dataset {i}", flush=True)

    combined_dataset = ConcatDataset(datasets)
    testing_ds = DataLoader(combined_dataset, batch_size = batch_size, shuffle = False, drop_last = True, num_workers = 2)
    
    print(f"---------------------------------", flush=True)
    print(f"Finished preparing all datasets", flush=True)
    
    input_64, target_64, output_64 = [], [], []
    input_256, target_256, output_256 = [], [], []

    # Start sampling
    for i, (x, y, z) in enumerate(testing_ds):
        # x: LR 16x16, y: MR 64x64, z: HR 256x256
        print(f"---------------------------------", flush=True)
        print(f"Processing batch {i + 1}/{len(testing_ds)}...", flush=True)

        stime = time()
        with torch.no_grad():

            y_sample = torch.randn_like(y, device = device)
            z_sample = torch.randn_like(z, device = device)

            x = x.to(device)
            y = y.to(device)
            z = z.to(device)

            # Stage 1: 16x16 → 64x64
            for _, t in enumerate(range(ddpm1.time_steps - 1, 0 , -1)):
                alpha_t, alpha_t_hat, beta_t = ddpm1.alphas[t], ddpm1.alpha_hats[t], ddpm1.betas[t]
        
                t = torch.tensor(t, device = device).long()

                pred_noise1 = ddpm1(torch.cat([x, y_sample], dim = 1), alpha_t_hat.view(-1).to(device))
                y_sample = (torch.sqrt(1/alpha_t))*(y_sample - (1-alpha_t)/torch.sqrt(1 - alpha_t_hat) * pred_noise1)

                if t > 1:
                    noise = torch.randn_like(y_sample)
                    y_sample += torch.sqrt(beta_t) * noise

            # Upsample 64x64 to 256x256
            y_up = torch.nn.functional.interpolate(y_sample, size=(256, 256), mode="bicubic")

            # Stage 2: 64x64 → 256x256
            for _, t in enumerate(range(ddpm2.time_steps - 1, 0 , -1)):
                alpha_t, alpha_t_hat, beta_t = ddpm2.alphas[t], ddpm2.alpha_hats[t], ddpm2.betas[t]

                t = torch.tensor(t, device = device).long()

                pred_noise2 = ddpm1(torch.cat([y_up, z_sample], dim = 1), alpha_t_hat.view(-1).to(device))
                z_sample = (torch.sqrt(1/alpha_t))*(z_sample - (1-alpha_t)/torch.sqrt(1 - alpha_t_hat) * pred_noise2)

                if t > 1:
                    noise = torch.randn_like(z_sample)
                    z_sample += torch.sqrt(beta_t) * noise   

        ftime = time()

        print(f"Done denoising in {ftime - stime:.2f}s for batch {i + 1}", flush=True)

        input_64.append(x.cpu().numpy())
        target_64.append(y.cpu().numpy())
        output_64.append(y_sample.cpu().numpy())
        input_256.append(y_up.cpu().numpy())
        target_256.append(z.cpu().numpy())
        output_256.append(z_sample.cpu().numpy())

        if i == 4:
            break

    input_64 = np.concatenate(input_64, axis=0)
    target_64 = np.concatenate(target_64, axis=0)
    output_64 = np.concatenate(output_64, axis=0)
    input_256 = np.concatenate(input_256, axis=0)
    target_256 = np.concatenate(target_256, axis=0)
    output_256 = np.concatenate(output_256, axis=0)

    # Saving the outputs in the desired format
    np.save("save_path", input_64)
    np.save("save_path", target_64)
    np.save("save_path", output_64)
    np.save("save_path", input_256)
    np.save("save_path", target_256)
    np.save("save_path", output_256)

    print("Saved all sampled results!", flush=True)


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    path = "test_data_path"
    ds = xr.open_zarr(path)

    ddpm1 = DiffusionModel1(time_steps=1000)
    ddpm2 = DiffusionModel2(time_steps=1000)

    # load joint trained checkpoint
    checkpoint_path = "checkpoint_path/sr_joint_12.pt"
    ckpt = torch.load(checkpoint_path, map_location=device)
    ddpm1.model.load_state_dict(ckpt["ddpm1"])
    ddpm2.model.load_state_dict(ckpt["ddpm2"])

    sample(ddpm1, ddpm2, wind_ds=ds["wind_speed"], device=device, batch_size=16)