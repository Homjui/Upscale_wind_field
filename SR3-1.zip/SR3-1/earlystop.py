class EarlyStopper:

    def __init__(self, patience=5, min_delta=1e-4):

        self.patience = patience
        self.min_delta = min_delta
        self.best_loss = float('inf')
        self.counter = 0

    def should_stop(self, loss):
        
        if loss < self.best_loss - self.min_delta:
            self.best_loss = loss
            self.counter = 0
        else:
            self.counter += 1
        
        return self.counter >= self.patience