from dataprocessing import *
from modules import DiffusionModel

from time import time
import torch
from torch.utils.data import Dataset, DataLoader, ConcatDataset
import matplotlib.pyplot as plt

def sample(trained_model, wind_ds = None, device = "cuda", batch_size = 16):
    # Load the trained model
    trained_model.to(device)
    trained_model.eval()

    # Prepare testing data
    datasets = []
    tite_number = wind_ds.shape[0]

    for i in range(tite_number):
        sub_wind_ds = wind_ds.sel(tile=i) # sub_wind_ds: (24, 256, 256)

        datasets.append(SRDataset(hr_data=sub_wind_ds.values, hr_sz=256, lr_sz=64))
        if i % 10 == 0:
            print(f"Finished preparing dataset {i}", flush=True)


    combined_dataset = ConcatDataset(datasets)
    testing_ds = DataLoader(combined_dataset, batch_size = batch_size, shuffle = False, drop_last = True, num_workers = 2)
    
    print(f"---------------------------------", flush=True)
    print(f"Finished preparing all datasets", flush=True)
    
    output = []
    input = []
    target = []

    # Start sampling
    for i, (lr_data, hr_data) in enumerate(testing_ds):
        # lr_data: (batchsize, 1, 256, 256)

        print(f"---------------------------------", flush=True)
        print(f"Processing batch {i + 1}/{len(testing_ds)}...", flush=True)

        stime = time()

        with torch.no_grad():

            # y: (batchsize, 1, 256, 256)
            y = torch.randn_like(lr_data, device = device)

            lr_data = lr_data.to(device)
            hr_data = hr_data.to(device)

            for _, t in enumerate(range(trained_model.time_steps - 1, 0 , -1)):
                alpha_t, alpha_t_hat, beta_t = trained_model.alphas[t], trained_model.alpha_hats[t], trained_model.betas[t]
        
                t = torch.tensor(t, device = device).long()
                pred_noise = trained_model(torch.cat([lr_data, y], dim = 1), alpha_t_hat.view(-1).to(device))
                y = (torch.sqrt(1/alpha_t))*(y - (1-alpha_t)/torch.sqrt(1 - alpha_t_hat) * pred_noise)
                
                if t > 1:
                    noise = torch.randn_like(y)
                    y = y + torch.sqrt(beta_t) * noise
            
        ftime = time()
        print(f"Done denoising in {ftime - stime}s for batch {i + 1}", flush=True)

        input.append(lr_data.cpu().numpy())
        target.append(hr_data.cpu().numpy())
        output.append(y.cpu().numpy())
        print(f"Finished processing batch {i + 1}", flush=True)
    
        if i == 4:
            break

    input_numpy = np.concatenate(input, axis=0)
    target_numpy = np.concatenate(target, axis=0)
    output_numpy = np.concatenate(output, axis=0)

    # Saving the outputs in the desired format
    np.save("save_path", input_numpy)
    np.save("save_path", target_numpy)
    np.save("save_path", output_numpy)


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    path = "test_data_path"
    ds = xr.open_zarr(path)

    trained_model = DiffusionModel(time_steps=1000)
    trained_model.load_state_dict(torch.load("output_path/sr_19.pt",
                                              map_location=device, weights_only=True))
    trained_model.to(device)
    
    sample(trained_model, wind_ds = ds["wind_speed"], device = device, batch_size = 32)
